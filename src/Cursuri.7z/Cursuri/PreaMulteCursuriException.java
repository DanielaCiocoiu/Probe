package Cursuri;

public class PreaMulteCursuriException extends Exception {
    public PreaMulteCursuriException(String message) {
        super(message);
    }
}
